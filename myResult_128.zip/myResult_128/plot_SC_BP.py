import numpy as np
import math
import matplotlib.pyplot as plt

# bit SNR in dB
X = [1, 1.5, 2, 2.5, 3, 3.5, 4]
# my SC decoder
Y0 = [0.396825, 0.274725, 0.141443, 0.066445, 0.020982, 0.006499, 0.001880]
# my BP decoder
Y1 = [0.401606, 0.256410, 0.112740, 0.052029, 0.015858, 0.004941, 0.001740]
# ref from Po-Chung
y_SC = [0.476, 0.283, 0.138, 0.0543, 0.0243, 0.0075, 0.0024]
y_BP = [0.493, 0.24, 0.112, 0.049, 0.0181, 0.00795, 0.00251]

plt.figure()
line0, = plt.plot(X, Y0, 'k.-', markersize = 5, linewidth = 1)
line1, = plt.plot(X, Y1, 'b.-', markersize = 5, linewidth = 1)
line2, = plt.plot(X, y_SC, 'y.--', markersize = 5, linewidth = 1)
line3, = plt.plot(X, y_BP, 'g.--', markersize = 5, linewidth = 1)
plt.xlabel("BSNR (dB)")
plt.ylabel("BLER")
plt.title("N = 128  K = 64    Error block = 100")
plt.grid('--', which='both', axis='both')
plt.yscale("log")
#plt.yticks([0.5, 0.2, 0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001])
plt.xticks([1, 2, 3, 4])
plt.xlim([1, 4])
#plt.ylim([1e-6, 1e-1])
plt.legend((line0, line1, line2, line3), ('SC', 'BP', 'SC ref', 'BP ref'))
plt.show()

