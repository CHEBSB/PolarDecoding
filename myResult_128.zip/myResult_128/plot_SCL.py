import numpy as np
import math
import matplotlib.pyplot as plt

# bit SNR in dB
X = [1, 1.5, 2, 2.5, 3, 3.5]
# my SCL decoder
L2 = [0.3125000, 0.1689189, 0.0746269, 0.0401606, 0.0084760, 0.0038133]
L4 = [0.2732240, 0.1246883, 0.0574713, 0.0271003, 0.0085426, 0.0029610]
L8 = [0.2450980, 0.1216545, 0.0591716, 0.0256016, 0.0086972, 0.0029628]
L16 = [0.2347418, 0.1240695, 0.0582751, 0.0253678, 0.0087458, 0.0029628]
L32 = [0.2347418, 0.1201923, 0.0572082, 0.0257467, 0.0087458, 0.0029628]
# SCL ref from Po-Chung
y2 = [0.314, 0.189, 0.0789, 0.0269, 0.0115, 0.00397]
y4 = [0.286, 0.133, 0.0571, 0.0232, 0.00936, 0.00394]
y8 = [0.266, 0.121, 0.0546, 0.0227, 0.00993, 0.00394]
y16 = [0.251, 0.118, 0.0546, 0.0219, 0.00993, 0.00394]
y32 = [0.251, 0.118, 0.0546, 0.0219, 0.00993, 0.00394]

plt.figure()
line0, = plt.plot(X, L2, 'k.-', markersize = 5, linewidth = 1)
line1, = plt.plot(X, L4, 'y.-', markersize = 5, linewidth = 1)
line2, = plt.plot(X, L8, 'b.-', markersize = 5, linewidth = 1)
line3, = plt.plot(X, L16, 'g.-', markersize = 5, linewidth = 1)
line4, = plt.plot(X, L32, 'r.-', markersize = 5, linewidth = 1)
ref0, = plt.plot(X, y2, 'k.--', markersize = 5, linewidth = 1)
ref1, = plt.plot(X, y4, 'y.--', markersize = 5, linewidth = 1)
ref2, = plt.plot(X, y8, 'b.--', markersize = 5, linewidth = 1)
ref3, = plt.plot(X, y16, 'g.--', markersize = 5, linewidth = 1)
ref4, = plt.plot(X, y32, 'r.--', markersize = 5, linewidth = 1)
plt.xlabel("BSNR (dB)")
plt.ylabel("BLER")
plt.title("N = 128  K = 64    Error block = 50")
plt.grid('--', which='both', axis='both')
plt.yscale("log")
#plt.yticks([0.5, 0.2, 0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001])
#plt.xticks([1, 2, 3, 4])
#plt.xlim([1, 4])
#plt.ylim([1e-6, 1e-1])
plt.legend((line0, line1, line2, line3, line4,
    ref0, ref1, ref2, ref3, ref4),
    ('L = 2', 'L = 4', 'L = 8', 'L = 16', 'L = 32',
    'ref L = 2', 'ref L = 4', 'ref L = 8', 'ref L = 16', 'ref L = 32'))
plt.show()

