import numpy as np
import math
import matplotlib.pyplot as plt

# bit SNR in dB
X = [1, 1.5, 2, 2.5, 3, 3.5, 4]
X_BP = [1, 1.5, 2, 2.5, 3, 3.5]
# my SC decoder
Y0 = [0.729927007, 0.374531835, 0.090090090, 0.014513788, 1.767815e-3, 0.196436e-3, 0.022669e-3]
# my BP decoder
Y1 = [442.477876e-3, 136.425648e-3, 29.481132e-3, 7.592438e-3, 1.130301e-3, 0.195061e-3]
# ref from Po-Chung
y_SC = [0.685, 0.364, 0.0865, 0.0156, 0.00159, 0.000162, 2e-5]
y_BP = [0.532, 0.166, 0.0395, 0.00676, 0.00117, 0.000234]

plt.figure()
line0, = plt.plot(X, Y0, 'k.-', markersize = 5, linewidth = 1)
line1, = plt.plot(X_BP, Y1, 'g.-', markersize = 5, linewidth = 1)
line2, = plt.plot(X, y_SC, 'k.--', markersize = 5, linewidth = 1)
line3, = plt.plot(X_BP, y_BP, 'g.--', markersize = 5, linewidth = 1)
plt.xlabel("BSNR (dB)")
plt.ylabel("BLER")
plt.title("N = 1024  K = 512    Error block = 100")
plt.grid('--', which='both', axis='both')
plt.yscale("log")
#plt.xticks([1, 2, 3, 4])
#plt.xlim([1, 4])
plt.legend((line0, line1, line2, line3), ('SC', 'BP', 'SC ref', 'BP ref'))
plt.show()

